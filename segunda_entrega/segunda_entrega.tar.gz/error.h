
#define E_X_LINEA 20


int errores_x_linea[ E_X_LINEA ];
int cant_errores_x_linea;

